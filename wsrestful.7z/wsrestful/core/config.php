<?php 

 /* 
  * En este archivo se definiran la información de configuracion del API,
  * variables, constantes y funciones requeridas para el resto de los archivos
 */

 // Dirección del servidor de Base de datos
 define("DB_HOST", "localhost");

 // Nombre de usuario de Base de datos
 define("DB_USER", "root");

 // Clave de usuario de Base de datos
 define("DB_PASS", "123456");

 // Nombre de la tabla sobre la cual se trabajara
 define("DB_NAME", "test");
?>